export async function hybridChat(
  prompt: string,
  model = 'Gertner/SlavkoKernel_v3'
) {
  const res = await fetch('/api/chat/hybrid', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt, model }),
  });

  if (!res.ok) throw new Error(`Status ${res.status}`);
  const data = await res.json();
  return data.response;
}