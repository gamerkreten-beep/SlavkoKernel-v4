import { useState } from 'react';
import { hybridChat } from '../services/hybridClient';

export default function HybridChat() {
  const [prompt, setPrompt] = useState('');
  const [reply, setReply] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const send = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await hybridChat(prompt);
      setReply(res);
    } catch (e: any) {
      setError(e.message || 'Unknown error');
      setReply(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-4">
      <h2 className="text-xl font-semibold mb-4">Hybrid Chat (SlavkoKernel)</h2>
      <div className="flex gap-2 mb-2">
        <input
          className="flex-1 border rounded p-1"
          placeholder="Type your prompt…"
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          disabled={loading}
        />
        <button
          className="bg-teal-500 text-white px-4 py-1 rounded disabled:opacity-50"
          onClick={send}
          disabled={loading || !prompt.trim()}
        >
          {loading ? '…' : 'Send'}
        </button>
      </div>
      {error && <p className="text-red-500">{error}</p>}
      {reply && (
        <pre className="bg-gray-50 p-4 rounded mt-4 whitespace-pre-wrap">
          {reply}
        </pre>
      )}
    </div>
  );
}