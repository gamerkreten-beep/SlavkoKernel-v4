import { BrowserRouter, Routes, Route } from 'react-router-dom';
import HybridChat from './pages/HybridChat';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/hybrid-chat" element={<HybridChat />} />
        <Route path="/" element={<h1>Welcome!</h1>} />
      </Routes>
    </BrowserRouter>
  );
}