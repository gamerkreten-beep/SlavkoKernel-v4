import StatusPill from './components/StatusPill.jsx'
import CircularGauge from './components/CircularGauge.jsx'
import TelemetryCard from './components/TelemetryCard.jsx'
import SnapshotTree from './components/SnapshotTree.jsx'
import Sparkline from './components/Sparkline.jsx'
import { ChevronLeft, ChevronRight, Search, User } from 'lucide-react'

const snapshotData = {
  key: 'telemetric_data',
  children: [
    { key: 'parent_event_time', value: '11:49:23' },
    { key: 'has_error', children: [
      { key: 'false', value: true },
      { key: 'true', value: false }
    ]},
    { key: 'error_message', error: true }
  ]
}

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Nav */}
      <header className="border-b border-white/5 bg-panel/60 backdrop-blur">
        <div className="mx-auto max-w-7xl px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-6">
              <div className="font-bold tracking-wide text-ink/90">SLAVKO KERNEL</div>
              <nav className="hidden md:flex items-center gap-4 text-sm">
                {['Overview','Telemetry','Health','Snapshot','Diagnostics'].map(t=>(
                  <a key={t} href="#" className="text-ink/70 hover:text-ink">{t}</a>
                ))}
              </nav>
            </div>
            <div className="flex items-center gap-3">
              <StatusPill color="cyan">Polling</StatusPill>
              <StatusPill color="orange">Buffer Full</StatusPill>
              <StatusPill color="red">Kernel Error</StatusPill>
              <StatusPill color="green">Healthy</StatusPill>
              <div className="hidden sm:flex items-center gap-2 rounded bg-panel/70 px-3 py-1 text-sm">
                <span className="text-mute">Persona</span>
                <span className="font-medium text-purple">Aurora</span>
                <User size={16} className="text-purple" />
              </div>
            </div>
          </div>

          {/* Status bar */}
          <div className="py-2 flex items-center gap-2 overflow-x-auto scroll-thin">
            <div className="h-2 flex-1 rounded bg-[#0b1430]">
              <div className="h-2 w-1/3 rounded bg-gradient-to-r from-coral to-orange" />
            </div>
            <span className="text-xs text-mute">Kernel Status</span>
          </div>
        </div>
      </header>

      {/* Main Grid */}
      <main className="mx-auto max-w-7xl w-full flex-1 px-4 py-4 grid grid-cols-1 lg:grid-cols-4 gap-4">

        {/* Left: System Analytics */}
        <section className="lg:col-span-1 space-y-4">
          <div className="rounded-xl border border-white/5 bg-panel/60 p-4">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold">System Analytics</h2>
              <div className="flex gap-2 text-xs text-mute">
                <span className="text-cyan">Overview</span>
                <span>Telemetry</span>
                <span>Health</span>
                <span>Snapshot</span>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-panel/60 p-3">
                <CircularGauge value={56} accent="cyan" label="CPU usage" />
              </div>
              <div className="rounded-lg bg-panel/60 p-3">
                <CircularGauge value={63} accent="orange" label="Memory usage" />
              </div>
            </div>
            <div className="mt-4">
              <div className="text-xs text-mute mb-2">Trending</div>
              <Sparkline values={[0.2,0.25,0.4,0.35,0.6,0.55,0.7,0.68]} color="#00d1ff" />
            </div>

            <div className="mt-4 flex items-center justify-between text-sm text-mute">
              <button className="inline-flex items-center gap-1 hover:text-ink/90">
                <ChevronLeft size={16}/> Previous
              </button>
              <button className="inline-flex items-center gap-1 hover:text-ink/90">
                Next <ChevronRight size={16}/>
              </button>
            </div>
          </div>

          {/* Events */}
          <div className="rounded-xl border border-white/5 bg-panel/60 p-4">
            <h3 className="font-semibold mb-3">Events</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span className="text-mute">1:13:15</span>
                <span className="text-red font-medium">ResolveError</span>
                <span className="text-mute">Error - 2 bytes Mismatch</span>
              </li>
              <li className="flex justify-between">
                <span className="text-mute">11:49:23</span>
                <span className="text-green">User connected</span>
                <span className="text-mute">ok</span>
              </li>
              <li className="flex justify-between">
                <span className="text-mute">11:47:45</span>
                <span className="text-amber">Login attempt exceeded</span>
                <span className="text-mute">rate-limit</span>
              </li>
            </ul>
            <div className="mt-3 h-2 rounded bg-[#0b1430]">
              <div className="h-2 w-1/2 rounded bg-coral/80"></div>
            </div>
          </div>
        </section>

        {/* Center: Telemetry Streams */}
        <section className="lg:col-span-2 space-y-4">
          <div className="rounded-xl border border-white/5 bg-panel/60 p-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute"/>
                <input
                  placeholder="Search telemetry..."
                  className="w-full rounded bg-[#0b1430] pl-9 pr-3 py-2 text-sm outline-none focus:ring-2 ring-cyan/40"
                />
              </div>
              <StatusPill color="cyan">Kernel Polling</StatusPill>
            </div>

            <div className="mt-4 space-y-3">
              <TelemetryCard
                level="INFO"
                title="ResolveError"
                meta="~1 | Error - 3 bytes Mismatch"
                lines={[
                  '2025-10-17T01:13:15Z INFO ResolveError id=7',
                  'mismatch=3B seq=164 component=telemetry'
                ]}
              />
              <TelemetryCard
                level="WARN"
                title="ResolveError (8PM)"
                meta="4 ⇒ 164 | Error"
                lines={[
                  'WARN ResolveError bucket=4->164',
                  'retry=2 backoff=320ms'
                ]}
              />
              <div className="rounded-lg border border-white/5 bg-panel/70 p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-red">ERROR</span>
                    <span className="text-sm text-mute">—</span>
                    <span className="font-medium">Aurora</span>
                  </div>
                  <div className="text-xs text-mute">Utter_weight: 33.42</div>
                </div>
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-1">
                    <div className="rounded bg-panel/60 p-3">
                      <div className="text-xs text-mute mb-2">Indicator</div>
                      <div className="text-3xl font-semibold text-red">210%</div>
                    </div>
                  </div>
                  <div className="sm:col-span-2">
                    <div className="rounded bg-panel/60 p-3">
                      <div className="text-xs text-mute mb-2">Trend</div>
                      <Sparkline color="#ff4d4f" values={[0.1,0.2,0.3,0.55,0.9,0.8,1]} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Polling dots */}
              <div className="flex items-center gap-2 text-xs text-mute">
                <span>Polling</span>
                <span className="flex gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse"></span>
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse [animation-delay:150ms]"></span>
                  <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse [animation-delay:300ms]"></span>
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Right: Snapshot Diff + Health */}
        <aside className="lg:col-span-1 space-y-4">
          <div className="rounded-xl border border-white/5 bg-panel/60 p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Snapshot Diff</h3>
              <div className="flex gap-2 text-xs">
                <button className="text-cyan hover:underline">EXPAND ALL</button>
                <button className="text-mute hover:text-ink">Collapse All</button>
                <button className="text-mute hover:text-ink">Split View</button>
              </div>
            </div>
            <div className="mt-3 max-h-64 overflow-auto pr-1">
              <SnapshotTree data={snapshotData} />
            </div>
          </div>

          <div className="rounded-xl border border-white/5 bg-panel/60 p-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Health Stats</h3>
              <span className="text-xs rounded bg-green/15 text-green px-2 py-0.5">Trending UP</span>
            </div>
            <div className="mt-3">
              <Sparkline color="#23d18b" values={[0.3,0.35,0.4,0.45,0.6,0.7,0.8]} />
            </div>
            <div className="mt-3 flex items-center justify-between text-sm">
              <span className="text-mute">Version</span>
              <span className="font-mono">v2 31.4</span>
            </div>
            <div className="mt-2">
              <a className="text-cyan text-sm hover:underline" href="#">Audit Log</a>
            </div>
          </div>
        </aside>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-panel/60">
        <div className="mx-auto max-w-7xl px-4 py-2 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2 text-mute">
            <span>Kernel Polling</span>
            <span className="flex gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse"></span>
              <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse [animation-delay:120ms]"></span>
              <span className="h-1.5 w-1.5 rounded-full bg-cyan/60 animate-pulse [animation-delay:240ms]"></span>
            </span>
          </div>
          <div className="text-mute">Kernel v2 31.4 • Persona: Aurora</div>
        </div>
      </footer>
    </div>
  )
}