import Sparkline from './Sparkline.jsx'

const badgeColors = {
  INFO: 'text-cyan',
  WARN: 'text-amber',
  ERROR: 'text-red'
}

export default function TelemetryCard({ level='INFO', title, meta, lines=[], chart=true }) {
  return (
    <div className="rounded-lg border border-white/5 bg-panel/50 p-4 hover:bg-panel/70 transition-colors">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold ${badgeColors[level]}`}>{level}</span>
          <span className="text-sm text-mute">—</span>
          <span className="font-medium">{title}</span>
        </div>
        {chart && <Sparkline color={level==='ERROR' ? '#ff4d4f' : level==='WARN' ? '#ffcc66' : '#00d1ff'} />}
      </div>
      <div className="mt-2 text-sm text-mute">{meta}</div>
      <div className="mt-3 space-y-1 font-mono text-xs">
        {lines.map((l,i)=>(
          <div key={i} className="text-ink/80">{l}</div>
        ))}
      </div>
    </div>
  )
}