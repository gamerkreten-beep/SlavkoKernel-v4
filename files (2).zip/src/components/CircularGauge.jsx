import React from 'react'

export default function CircularGauge({
  value=0,
  size=120,
  stroke=10,
  label='',
  accent='cyan',
}) {
  const r = (size - stroke) / 2
  const circumference = 2 * Math.PI * r
  const pct = Math.max(0, Math.min(100, value))
  const dash = (pct / 100) * circumference
  const color = {
    cyan: '#00d1ff',
    orange: '#ffb366',
    coral: '#ff7a59',
    purple: '#9b5cff',
    green: '#23d18b',
    red: '#ff4d4f'
  }[accent] || '#00d1ff'

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={size} height={size} className="rotate-[-90deg]">
        <circle
          cx={size/2} cy={size/2} r={r}
          stroke="#1b2544"
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size/2} cy={size/2} r={r}
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${dash} ${circumference-dash}`}
          fill="none"
        />
      </svg>
      <div className="text-3xl font-semibold -mt-[calc(50%)] pointer-events-none select-none">
        {Math.round(value)}%
      </div>
      <div className="text-sm text-mute">{label}</div>
    </div>
  )
}