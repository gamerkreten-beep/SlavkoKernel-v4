export default function Sparkline({ values=[], width=140, height=36, color='#23d18b' }) {
  if (!values.length) values = [0.2,0.4,0.3,0.7,0.6,0.8,0.5]
  const step = width / (values.length - 1 || 1)
  const pts = values.map((v, i) => `${i*step},${height - v*height}`).join(' ')
  return (
    <svg width={width} height={height} className="opacity-90">
      <polyline fill="none" stroke={color} strokeWidth="2" points={pts} />
    </svg>
  )
}