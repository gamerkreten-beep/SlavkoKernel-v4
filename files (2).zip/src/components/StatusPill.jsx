export default function StatusPill({ color='cyan', children, dot=true }) {
  const colorMap = {
    cyan: 'bg-cyan text-cyan',
    orange: 'bg-orange text-orange',
    coral: 'bg-coral text-coral',
    red: 'bg-red text-red',
    green: 'bg-green text-green',
    purple: 'bg-purple text-purple',
  }
  const c = colorMap[color] || colorMap.cyan
  return (
    <span className="inline-flex items-center gap-2 rounded-full bg-panel/60 px-3 py-1 text-sm">
      {dot && <span className={`h-2 w-2 rounded-full ${c.split(' ')[0]}`} />}
      <span className={`${c.split(' ')[1]} font-medium`}>{children}</span>
    </span>
  )
}