import React from 'react'

function Node({ node, depth=0 }) {
  const [open, setOpen] = React.useState(true)
  const isLeaf = !node.children || node.children.length===0
  return (
    <div className="my-1">
      <div
        className="flex items-center gap-2 cursor-pointer"
        onClick={() => !isLeaf && setOpen(!open)}
        style={{ paddingLeft: depth*10 }}
      >
        {!isLeaf && (
          <span className="text-mute text-xs w-4">{open ? '▾' : '▸'}</span>
        )}
        <span className="text-sm">
          <span className="text-ink/90">{node.key}</span>
          {node.value !== undefined && (
              <span className="text-mute">: {String(node.value)}</span>
          )}
          {node.error && (
            <span className="ml-2 rounded bg-red/20 px-2 py-0.5 text-xs text-red">Resolve ==Error==</span>
          )}
        </span>
      </div>
      {open && node.children && (
        <div className="mt-1">
          {node.children.map((c,i)=>(
            <Node key={i} node={c} depth={depth+1} />
          ))}
        </div>
      )}
    </div>
  )
}

export default function SnapshotTree({ data }) {
  return <div className="text-sm">{data && <Node node={data} />}</div>
}