/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#0c1220',
        panel: '#10192e',
        ink: '#e8f1ff',
        cyan: '#00d1ff',
        coral: '#ff7a59',
        orange: '#ffb366',
        purple: '#9b5cff',
        red: '#ff4d4f',
        green: '#23d18b',
        amber: '#ffcc66',
        mute: '#7c8aa3'
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'monospace']
      }
    }
  },
  plugins: []
}