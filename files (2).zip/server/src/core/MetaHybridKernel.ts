import { GeminiService } from '../services/GeminiService';
import { V0DevAdapter } from '../providers/V0DevAdapter';
import { SlavkoScoreEngine } from '../scoring/SlavkoScoreEngine';
import { FibonacciWeightingStrategy } from '../strategies/FibonacciWeightingStrategy';
import { logger } from '../utils/logger';
import { retry } from '../utils/retry';
import { circuitBreaker } from '../utils/circuitBreaker';

export class MetaHybridKernel {
  private geminiService = new GeminiService(process.env.GOOGLE_API_KEY!);
  private v0Adapter = new V0DevAdapter(process.env.V0DEV_API_KEY!);
  private scoringEngine = new SlavkoScoreEngine();
  private weightingStrategy = new FibonacciWeightingStrategy();

  async orchestrate(prompt: string, model = 'Gertner/SlavkoKernel_v3') {
    try {
      logger.info({ prompt }, 'Starting hybrid workflow');

      /* 1️⃣ Semantic analysis */
      const analysis = await retry(() => this.geminiService.analyze(prompt, model));

      /* 2️⃣ Scoring */
      const score = this.scoringEngine.evaluate(analysis, this.weightingStrategy);

      /* 3️⃣ UI component suggestion */
      const components = await circuitBreaker(() =>
        this.v0Adapter.generate(analysis, score)
      );

      /* 4️⃣ (Optional) iterative refinement – omitted for brevity */
      return { analysis, score, components };
    } catch (err: any) {
      logger.error(err, 'Hybrid workflow failed');
      throw err;
    }
  }
}