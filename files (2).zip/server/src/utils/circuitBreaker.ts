import { logger } from './logger';

export async function circuitBreaker<T>(
  fn: () => Promise<T>,
  threshold = 5,
  timeoutMs = 2000
): Promise<T> {
  let failures = 0;
  const start = Date.now();

  try {
    return await fn();
  } catch (e) {
    failures += 1;
    logger.warn({ failures }, 'Circuit breaker triggered');

    if (failures >= threshold) {
      throw new Error('Circuit open – too many failures');
    }

    // Back‑off logic
    const delay = Math.min(timeoutMs * Math.pow(2, failures), 4000);
    await new Promise(r => setTimeout(r, delay));
    if (Date.now() - start > timeoutMs * 4) throw e;

    return circuitBreaker(fn, threshold, timeoutMs);
  }
}