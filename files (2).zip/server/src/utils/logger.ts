import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  formatters: {
    level(label) {
      return { level: label };
    },
  },
});

export function loggerMiddleware(req, res, next) {
  logger.info({ method: req.method, url: req.url }, 'Incoming request');
  next();
}