import { Hono } from 'hono';
import { MetaHybridKernel } from '../core/MetaHybridKernel';
import { z } from 'zod';

const router = new Hono();
const kernel = new MetaHybridKernel();

router.post(
  '/hybrid',
  async (c) => {
    const body = await c.req.json();

    const schema = z.object({
      prompt: z.string(),
      model: z.string().optional(),
    });

    const { prompt, model } = schema.parse(body);

    try {
      const res = await kernel.orchestrate(prompt, model);
      return c.json({ success: true, data: res });
    } catch (e: any) {
      return c.json({ success: false, error: e.message || e }, 500);
    }
  }
);

export default router;