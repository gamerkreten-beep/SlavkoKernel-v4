import 'dotenv/config';
import express from 'express';
import { Hono } from 'hono';
import chatRoutes from './routes/chat';
import { loggerMiddleware } from './utils/logger';
import { requestCount, requestDuration } from './metrics/prometheus';
import { Response, Request } from 'express';

const app = express();
app.use(express.json());
app.use(loggerMiddleware);

const hono = new Hono();
hono.route('/api/chat', chatRoutes);
app.use(hono.fetch);

function metricsHandler(_req: Request, res: Response) {
  res.set('Content-Type', 'text/plain');
  return res.send(require('prom-client').register.metrics());
}
app.get('/metrics', metricsHandler);

const port = process.env.PORT ? +process.env.PORT : 4000;
app.listen(port, () => {
  console.log(`🚀 Slavko Kernel v4 listening on http://localhost:${port}`);
});