import { FibonacciWeightingStrategy } from '../strategies/FibonacciWeightingStrategy';

export class SlavkoScoreEngine {
  evaluate(analysis: any, weighting: FibonacciWeightingStrategy) {
    const subscores = {
      performance: this.calcPerformance(analysis.complexity),
      accessibility: this.calcAccessibility(analysis.recommendedComponents.length),
      innovation: this.calcInnovation(analysis.potentialChallenges.length),
    };

    const overall = weighting.computeAdaptiveWeight(subscores);
    return { overall, subscores };
  }

  private calcPerformance(complexity: number) {
    return complexity > 5 ? 0.8 : 0.6;
  }

  private calcAccessibility(count: number) {
    return count > 2 ? 0.9 : 0.7;
  }

  private calcInnovation(challenges: number) {
    return challenges > 1 ? 0.85 : 0.6;
  }
}