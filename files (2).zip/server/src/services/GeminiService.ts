import { GoogleGenAI, Type } from '@google/genai';
import { z } from 'zod';
import { logger } from '../utils/logger';

interface AIAnalysisResult {
  intent: string;
  complexity: number;
  recommendedComponents: string[];
  potentialChallenges: string[];
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor(apiKey: string) {
    this.ai = new GoogleGenAI({ apiKey });
  }

  async analyze(prompt: string, model: string): Promise<AIAnalysisResult> {
    const response = await this.ai.models.generateContent({
      model,
      contents: [
        { role: 'user', parts: [{ text: prompt }] },
      ],
      generationConfig: {
        temperature: 0.2,
      },
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          intent: { type: Type.STRING },
          complexity: { type: Type.NUMBER },
          recommendedComponents: { type: Type.ARRAY, items: { type: Type.STRING } },
          potentialChallenges: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['intent', 'complexity', 'recommendedComponents', 'potentialChallenges'],
      },
    });

    const body = JSON.parse(response.text);
    const schema = z.object({
      intent: z.string(),
      complexity: z.number(),
      recommendedComponents: z.array(z.string()),
      potentialChallenges: z.array(z.string()),
    });

    return schema.parse(body);
  }
}