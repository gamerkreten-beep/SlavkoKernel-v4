export class FibonacciWeightingStrategy {
  private seq = [1, 1, 2, 3, 5, 8, 13, 21];

  calculateWeight(index: number): number {
    return this.seq[Math.min(index, this.seq.length - 1)];
  }

  computeAdaptiveWeight(metrics: Record<string, number>): number {
    const entries = Object.entries(metrics);
    if (!entries.length) return 0;

    const weighted = entries.reduce((acc, [, val], i) => {
      return acc + val * this.calculateWeight(i);
    }, 0);

    return weighted / entries.length;
  }
}