import { collectDefaultMetrics, Counter, Histogram } from 'prom-client';

collectDefaultMetrics();

export const requestCount = new Counter({
  name: 'api_requests_total',
  help: 'Total number of API requests',
});
export const requestDuration = new Histogram({
  name: 'api_request_milliseconds',
  help: 'API request latency',
});