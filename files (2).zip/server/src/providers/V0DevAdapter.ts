import { request } from 'undici';
import { logger } from '../utils/logger';

export class V0DevAdapter {
  constructor(private apiKey: string) {}

  async generate(analysis: any, score: any) {
    const url = `https://api.v0.dev/v1/components`;
    const prompt = this.buildPrompt(analysis, score);
    const res = await request(url, {
      method: 'POST',
      body: JSON.stringify({
        prompt,
        model: 'nextjs-app-router',
      }),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
      },
    });

    const data = await res.body.json();
    logger.info({ components: data.components }, 'v0.dev returned components');
    return data.components;
  }

  private buildPrompt(analysis: any, score: any) {
    return `
      Build a minimal Next.js pages/app using the following:
      Intent: ${analysis.intent}
      Constraints: Score=${score.overall.toFixed(2)}
      Recommended UI: ${analysis.recommendedComponents.join(', ')}
      Complexity: ${analysis.complexity}
      Bonus: Ensure accessibility (ARIA) and performance (data‑fetching opt).
    `;
  }
}