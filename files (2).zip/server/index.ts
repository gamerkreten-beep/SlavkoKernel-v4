import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434';

app.use(cors());
app.use(express.json());

app.post('/api/chat/hybrid', async (req, res) => {
  const { prompt, model = 'Gertner/SlavkoKernel_v3' } = req.body;
  try {
    const ollamaRes = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, model })
    });
    const data = await ollamaRes.json();
    res.json({ response: data.message || data.response || data });
  } catch (err) {
    res.status(500).json({ error: 'Ollama error', details: err });
  }
});

app.get('/', (_req, res) => {
  res.send('SlavkoKernel backend is running');
});

app.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
});