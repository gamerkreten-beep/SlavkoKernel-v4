#!/usr/bin/env bash
set -euo pipefail

ROOT=$PWD

# 1️⃣ Start Ollama if needed
if ! command -v ollama &> /dev/null; then
  echo "🛠️ Installing Ollama…"
  curl -sSL https://ollama.com/install.sh | sh
else
  echo "✅ Ollama already installed."
fi

if ! lsof -i :11434 &> /dev/null; then
  echo "🚀 Starting Ollama server…"
  ( ollama serve &>/dev/null & )
  while ! nc -z localhost 11434; do sleep 0.5; done
  echo "✅ Ollama is ready."
else
  echo "✅ Ollama already running."
fi

# 2️⃣ Pull model
echo "⏳ Pulling Gertner/SlavkoKernel_v3…"
ollama pull Gertner/SlavkoKernel_v3

# 3️⃣ Backend setup
cd "$ROOT/server"
if [ ! -f ".env" ]; then
  echo "⚙️ Copying .env.example to .env"
  cp .env.example .env
fi
echo "📦 Installing backend deps…"
npm install
echo "🚀 Starting backend…"
npm run dev &

# 4️⃣ Frontend setup
cd "$ROOT/frontend"
echo "📦 Installing frontend deps…"
npm install
echo "🚀 Starting frontend…"
npm run dev &

cd "$ROOT"

echo "🌟 All services started!"
echo "  • Ollama: http://localhost:11434"
echo "  • Backend: http://localhost:4000"
echo "  • Frontend: http://localhost:5173"
echo "  • API: /api/chat/hybrid"