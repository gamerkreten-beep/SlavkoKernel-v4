# SlavkoKernel v4 – Hybrid AI Backend + Frontend

## Quickstart

1. Clone repo & fill in secrets:
   ```bash
   git clone https://github.com/your-org/slavko-kernel-v4.git
   cd slavko-kernel-v4/server
   cp .env.example .env   # set GOOGLE_API_KEY, V0DEV_API_KEY
   ```

2. Install & run backend:
   ```bash
   npm ci
   npm run dev
   # backend at http://localhost:4000
   ```

3. Install & run frontend:
   ```bash
   cd ../frontend
   npm ci
   npm run dev
   # frontend at http://localhost:5173
   ```

4. Test chat API:
   ```bash
   curl -X POST http://localhost:4000/api/chat/hybrid -H "Content-Type: application/json" -d '{"prompt":"Hello hybrid world"}'
   ```

## Docker

```bash
docker compose up
```

## Ollama Model Push

```bash
ollama push Gertner/SlavkoKernel_v3
```

## Observability

- `/metrics` endpoint (Prometheus)
- Logging via Pino

## CI/CD

- See `.github/workflows/ci.yml` for lint, test, deploy (Vercel)

---

**Feel free to expand with JWT auth, Apollo GraphQL, WebSocket streaming, caching, and more!**